# StreetFind V3

Proyecto web de StreetFind preparado para subir a GitHub.

- `index.html`: aplicación web principal.
- `README.md`: información del proyecto.

Nota: la versión incluida es la versión disponible del proyecto guardado. La integración de APIs/secretos debe hacerse mediante backend o variables de entorno y nunca exponiendo claves privadas en el frontend.
